chrome.devtools.panels.create(
  "Shop Parser",
  "",
  "devtools_panel.html",
  function(panel) {}
);

